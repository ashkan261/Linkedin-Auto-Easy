// background.js
// Minimal background script — no auto actions here.

chrome.runtime.onInstalled.addListener(() => {
  console.log("Linkedin Auto Easy installed.");
});

 